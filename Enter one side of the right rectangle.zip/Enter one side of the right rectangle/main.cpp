#include <iostream>

using namespace std;

int main()
{
    cout << "Enter one side of the right rectangle" << endl;

    int a;
    cin >> a;
    cout << "Enter the second side of the rectangle" << endl;
    int b;
    cin >> b;
    int S = a * b;
    int P = 2 * (a + b);

    cout << "Surface: " << S << "" << endl;
    cout << "PERIMETR: " << P << "";


    return 0;
}
